**Sticker Notes**

Palm tree sticker: 

* Style: Circle* Size: 2 inch round* Notes to printer: Blue should reach edges

Full logo sticker:

* Style: Rounded corner rectangle* Size: 2.5 inches wide* Notes to printer: Yellow background should reach edges

Crab sticker: 

* Style: Die cut with white background* Size: 1.25 inches wide and heigh* Notes to printer: White background and outline

Recommended vendor: stickermule.com